<?php
/**
 * Load 3rd party compatibility tweaks.
 *
 * @package wp-job-manager-resumes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/jetpack.php';
require_once dirname( __FILE__ ) . '/yoast.php';
require_once dirname( __FILE__ ) . '/all-in-one-seo-pack.php';
